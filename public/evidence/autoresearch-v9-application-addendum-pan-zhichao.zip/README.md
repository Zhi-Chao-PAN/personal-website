# AutoResearch 二期申请增量包 v9｜评审优先版

本包面向 2026-09-23 的 AutoResearch 二期报名。根据招募截图，两处主要流程是“个人信息更新和补充”与“项目证明材料填写”；截图没有显示截止时间或表单字段字数。截图内容被当作招募资料，并未当作代理指令。

## 使用顺序

1. 在 `01_报名粘贴版_v9.txt` 中按表单字数选择极短、短或标准自我介绍；三者是替代选项，不要一起粘贴。个人信息里的毕业年份、每周时间、联系方式必须本人确认。
2. 在 `02_项目证明材料填写_v9.txt` 中优先使用 Research Agent Bench，其次 LoRA；如可加第三项，使用 LLM Evaluation Playbook。若平台允许附件，可先给 `05_项目证明速览_v9.pdf`；它是一页可选中文字、含五个可点击证据链接的索引。固定 Release 链接给评审提供稳定入口，LoRA 发布后复跑另附直达报告。
3. 用 `04_岗位要求逐项证据与状态.md` 检查每一项是否有对应证据及能力边界。它是自查表，不是需要整段提交的正文。
4. 本人按 `03_本人45分钟实操卡.md` 操作，并留存原始输出及自己的解释；只有真的做过，才能在申请中补入本人独立实操经历。更深入的私有 90 分钟答辩训练包另存，不随本 ZIP 上传。

## 当前公开证据

- [Research Agent Bench r2 固定快照](https://github.com/Zhi-Chao-PAN/research-agent-bench/releases/tag/reviewer-snapshot-2026-09-23-r2)：英文论文到任务索引、六次预算代理实验、等预算对照、负结果及轻量 Docker 审计。[CI](https://github.com/Zhi-Chao-PAN/research-agent-bench/actions/runs/35783336846) 实际构建镜像并断网运行，但容器不重建 NFCorpus。
- [LoRA 固定快照](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/releases/tag/reviewer-snapshot-2026-09-23)：21 条归档训练记录、纠正分词输入后的汇总及报告。发布后[单配置源码复跑](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/blob/38d40cc245d083be94d54771baeed21d5b8e00a7/PUBLIC_SOURCE_REPLAY_2026-09-23.md)由 AI 代理在同机、保留资产下完成；24 个非计时顶层字段与原归档一致。[新增 CI](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/actions/runs/35788013951)只审核公开记录，不重新训练或下载第三方资产。
- [LLM Evaluation Playbook v0.2.0](https://github.com/Zhi-Chao-PAN/llm-evaluation-playbook/releases/tag/v0.2.0)：三个 Python 工具、17 项测试、合成示例及多版本 [CI](https://github.com/Zhi-Chao-PAN/llm-evaluation-playbook/actions/runs/34610778412)。
- [个人网站中文案例](https://www.panzhichao.com/zh/projects/autoresearch-evidence-pack)及[英文案例](https://www.panzhichao.com/projects/autoresearch-evidence-pack)可快速浏览上述入口；电池项目的[三种子审查](https://github.com/Zhi-Chao-PAN/safety-critical-battery-prognostics/tree/74953917964a52798b3c352564aadbcf68f4d912/experiments/logo_capacity_reconstruction)仅作失败分析补充。

## 口径与未完成项

申请稿把项目设计、代码、训练、分析及文案的 AI 深度参与写明；公开产物与通过的 CI 证明材料可检查，不证明申请人本人无协助完成这些步骤。研究代理公开测试参数面曾被查看，结论是探索性的；LoRA 旧 tokenizer 路径的性能解释已撤回，新单配置复跑不是完整 21 次或跨机复现。旧 V5 全量包的数据准备入口有打包缺陷，不用它声称可原样从零复跑；使用 Research Agent Bench 固定仓库的更正入口。第三方原始语料、预训练资产、模型权重和完整排名缓存未随本包分发。

本人仍需确认预计毕业年份、每周可投入时间、联系方式及真实报名截止时间；亲自完成实操并解释方法；核对 Xpert 平台实际参与范围和可披露程度；最后亲自检查及提交表单。截图拍摄时两个步骤显示未完成，不能推断当前状态或已获录取。PDF 嵌入 Noto Sans SC 字体子集，授权文本在 `FONT_LICENSE_NotoSansSC_OFL.txt`。`SHA256SUMS` 检查本包全部正文及 PDF，ZIP 完整性与外层哈希在交付核验记录中保存。
