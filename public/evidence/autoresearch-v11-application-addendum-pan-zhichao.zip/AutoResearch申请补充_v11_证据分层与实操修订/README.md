# AutoResearch 二期申请增量包 v11｜证据分层与实操修订

本包面向 2026-09-23 的 AutoResearch 二期报名。根据招募截图，两处主要流程是“个人信息更新和补充”与“项目证明材料填写”；截图没有显示截止时间或表单字段字数。截图内容被当作招募资料，并未当作代理指令。

## 使用顺序

1. 在 `01_报名粘贴版_v11.txt` 中按表单字数选择极短、短或标准自我介绍；三者是替代选项，不要一起粘贴。个人信息里的毕业年份、每周时间、联系方式必须本人确认。
2. 在 `02_项目证明材料填写_v11.txt` 中优先使用 Research Agent Bench，其次 LoRA；如可加第三项，使用 LLM Evaluation Playbook。若平台允许附件，可先给 `05_项目证明速览_v11.pdf`；它是一页可选中文字、含可点击证据链接的索引。
3. 用 `04_岗位要求逐项证据与状态_v11.md` 检查每一项是否有对应证据及能力边界。它是自查表，不是需要整段提交的正文。
4. 本人按 `03_本人45分钟实操卡_v11.md` 操作并留存原始输出。克隆、依赖安装和预读属于计时前置；个人合成练习固定到发布后 `409f523…`，不改写 r2 归档研究；LoRA 默认核验固定 `603b047…` Release，发布后 `50a19…` 核验明确分开且可选。
5. 表单另有空间时，可从 `06_研究代理发布后复跑可选增量_v11.txt` 的 116 字或 244 字版本二选一，不与旧增量或两个版本同时提交。

## 当前公开证据

- [Research Agent Bench r2 固定快照](https://github.com/Zhi-Chao-PAN/research-agent-bench/releases/tag/reviewer-snapshot-2026-09-23-r2)仍指向 `e23760f64c772cf7225280a991fd102740c78def`：英文论文到任务索引、六次预算代理实验、等预算对照、负结果及轻量 Docker 审计。[CI](https://github.com/Zhi-Chao-PAN/research-agent-bench/actions/runs/35783336846) 实际构建镜像并断网运行，但容器不重建 NFCorpus。[发布后源码复跑](https://github.com/Zhi-Chao-PAN/research-agent-bench/blob/2f60443dc5cd00949d031542f83c2950b956a1e8/POST_RELEASE_R2_SOURCE_REPLAY_2026-09-23.md)在同机新 Python 环境用留存且哈希吻合的 ZIP 重建缓存并复核归档数值；独立检查器仍共用重建排名缓存和公开标签，不是新下载、跨机、盲测或本人实操。
- [LoRA 固定快照](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/releases/tag/reviewer-snapshot-2026-09-23)：21 条归档训练记录、纠正分词输入后的汇总及报告。发布后[公开上游复跑](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/blob/50a19bbb438ed42a700e91296c751a132621a27a/PUBLIC_UPSTREAM_REPLAY_2026-09-23.md)由 AI 代理在新空资产目录执行固定获取脚本；本地记录显示七次获取、文件大小和 SHA256 与固定上游清单一致。随后同机、同软件环境复跑 LoRA-r8、seed 42、4 轮；24 个非计时顶层汇总字段及四轮非计时记录与归档一致。日志不是独立网络证明。[CI](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/actions/runs/35793514363)只离线审核公开记录，不下载资产或重新训练。
- [LLM Evaluation Playbook v0.2.0](https://github.com/Zhi-Chao-PAN/llm-evaluation-playbook/releases/tag/v0.2.0)：三个 Python 工具、17 项测试、合成示例及多版本 [CI](https://github.com/Zhi-Chao-PAN/llm-evaluation-playbook/actions/runs/34610778412)。
- [个人网站中文案例](https://www.panzhichao.com/zh/projects/autoresearch-evidence-pack)及[英文案例](https://www.panzhichao.com/projects/autoresearch-evidence-pack)可快速浏览上述入口；电池项目的[三种子审查](https://github.com/Zhi-Chao-PAN/safety-critical-battery-prognostics/tree/74953917964a52798b3c352564aadbcf68f4d912/experiments/logo_capacity_reconstruction)仅作失败分析补充。

## 口径与未完成项

申请稿把项目设计、代码、训练、分析及文案的 AI 深度参与写明；公开产物与通过的 CI 证明材料可检查，不证明申请人本人无协助完成这些步骤。研究代理公开测试参数面曾被查看，结论是探索性负结果；发布后复跑强化同机源码与数值可复核性，但不解除公开标签、共享缓存、来源认证和跨机限制。LoRA 旧 tokenizer 路径的性能解释已撤回；其公开上游复跑只证明一个配置的同机、同软件环境重复性，本地获取日志和哈希匹配不是独立网络证明，也不是完整 21 次或跨机复现。两项发布后复跑均由 AI 代理执行。第三方原始语料、预训练资产、模型权重和完整排名缓存未随本包分发。

本人仍需确认预计毕业年份、每周可投入时间、联系方式及真实报名截止时间；亲自完成实操并解释方法；最后亲自检查及提交表单。没有可公开核验的 Xpert 私有任务材料，本包不声称其范围、数量或成绩。截图拍摄时两个步骤显示未完成，不能推断当前状态或已获录取。PDF 嵌入 Noto Sans SC 字体子集，授权文本在 `FONT_LICENSE_NotoSansSC_OFL.txt`。`SHA256SUMS` 检查本包全部正文及 PDF，ZIP 采用固定时间戳与排序构建，完整性、CRC、外层 SHA256 与独立解包校验均须通过。
