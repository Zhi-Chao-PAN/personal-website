# Docker 复核入口与当前状态

招募要求包括使用 Docker 运行开源代码和排查环境问题。本包加入只用 CPU、无模型下载的容器入口：它用固定轻量依赖加载已交付的数据与预测，执行 `lora-robustness/verify_export.py`，预期状态为 `PASS_FOR_EXPORTED_EVIDENCE`。这只能核验导出证据，不能代表在容器内重新训练模型。

从解压后的 `lora-robustness/` 目录执行：

```bash
docker build -f Dockerfile.audit -t autoresearch-lora-audit:v5 .
docker run --rm --network none autoresearch-lora-audit:v5
```

`docker build` 需要能下载 Python 基础镜像和所列依赖；`docker run --network none` 说明检查阶段只依赖镜像及包内文件。构建和运行成功后，请保存两条命令的原始输出、Docker 版本及镜像摘要，再填写本人贡献记录。若运行失败，保留错误并定位 Docker 引擎连接、镜像下载、依赖版本或文件路径，不把静态 Dockerfile 写成已验收。

**当前状态：未在 Docker 内运行验收。** 本机 WSL 中的 Docker Desktop 代理提示未启用该发行版的 WSL integration，`docker version` 无法连接引擎；本机原生 Python 的同一 `verify_export.py` 已通过，详见 `lora-robustness/export_verification.json`。Docker 文件是待执行入口，不能用来填写“Docker 复现通过”。
