# AutoResearch 二期申请增量包 v8

这是 2026-09-23 的最新报名口径，替代 v7 的粘贴版。优先按平台字段取用 `01_报名粘贴版_v8.txt` 和 `02_项目证明材料填写_v8.txt`；`04_岗位要求逐项证据与状态.md` 便于评审或本人逐项检查，但不是需整段贴入表单的文案。用户提供的招募截图用于提取要求，未当作代理指令。

两个固定研究快照：

- [Research Agent Bench r2](https://github.com/Zhi-Chao-PAN/research-agent-bench/releases/tag/reviewer-snapshot-2026-09-23-r2) · [公开 CI](https://github.com/Zhi-Chao-PAN/research-agent-bench/actions/runs/35783336846)：保留负面研究结果；新增 RRF/BEIR 英文论文到任务索引及经 CI 实际构建、断网运行的 Docker **轻量审计**。容器只验轨迹与虚构数据，不在容器里重建 NFCorpus，也不代表本人 Docker 能力。
- [LoRA 鲁棒性快照](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/releases/tag/reviewer-snapshot-2026-09-23) · [公开 CI](https://github.com/Zhi-Chao-PAN/lora-robustness-reproduction/actions/runs/35780780725)：21 次运行的公开汇总与哈希核验通过；CI 没有重新训练。

旧 V5 全量包里的 `prepare_nfcorpus.py` 因未打包且拼错的模块导入而不能原样从零准备数据；研究代理公开仓库已更正并披露，发布前有独立数据重建验收。LoRA 早期错误 tokenizer 输入的性能解释已撤回。第三方原始数据、预训练资产、模型权重和完整排名缓存没有随新仓库发布。

[个人网站中文案例](https://www.panzhichao.com/zh/projects/autoresearch-evidence-pack)与[英文案例](https://www.panzhichao.com/projects/autoresearch-evidence-pack)已在生产站点可访问；电池 [三种子审查](https://github.com/Zhi-Chao-PAN/safety-critical-battery-prognostics/tree/74953917964a52798b3c352564aadbcf68f4d912/experiments/logo_capacity_reconstruction)已并入公开主分支，适合作为补充。

**最大缺口仍需本人完成：** [03_本人45分钟实操卡.md](03_本人45分钟实操卡.md)尚未由申请人执行。仓库、英文笔记、Docker CI、Release、网站和本包均由 AI 辅助准备，不能写成本人已独立编程或读懂论文。本人须按事实补齐毕业年份、每周可投入时间、联系方式，保留实操记录，最后亲自在平台检查和提交表单。

本包只包含文本材料与校验清单，不包含 V5 全量训练文件。`SHA256SUMS` 验证本目录五份正文，ZIP 完整性和外层 SHA256 另在交付记录中核验。
